def initialize(*args, **kargs):
    pass


def update_connection():
    pass


def run_callbacks():
    pass


def update_presence(**args):
    pass


def shutdown():
    pass


class RPC:
    def __init__(self, app_id: int, debug: bool = False, output: bool = True, exit_if_discord_close: bool = True):
        pass

    def set_activity(
        self,
        state: str = None,
        details: str = None,
        ts_start: int = None,
        ts_end: int = None,
        large_image: str = None,
        large_text: str = None,
        small_image: str = None,
        small_text: str = None,
        party_id: str = None,
        party_size: list = None,
        join_secret: str = None,
        spectate_secret: str = None,
        match_secret: str = None,
        buttons: list = None,
    ):

        pass

    def disconnect(self):
        pass

    def run(self, update_every: int = 1):
        pass


def Button(button_one_label: str, button_one_url: str, button_two_label: str, button_two_url: str):

    pass
