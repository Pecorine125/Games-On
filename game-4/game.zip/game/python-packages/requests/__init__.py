from requests.exceptions import RequestException

def get(*args, **kwargs):
    raise RequestException()

def post(*args, **kwargs):
    raise RequestException()