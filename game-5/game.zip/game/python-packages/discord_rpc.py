def initialize(*args, **kargs):
    pass


def update_connection():
    pass


def run_callbacks():
    pass


def update_presence(**args):
    pass


def shutdown():
    pass


class RPC:
    def __init__(self, *args, **kargs):
        pass

    def set_activity(self, *args, **kargs):

        pass

    def disconnect(self):
        pass

    def run(self, *args, **kargs):
        pass


def Button(*args, **kargs):

    pass
