class Request:
    def __init__(*args, **kwargs):
        pass


def urlopen(*args, **kwargs):
    pass
