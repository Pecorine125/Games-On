HTTP_PORT = 80

MOVED_PERMANENTLY = 301
FOUND = 302
SEE_OTHER = 303

class HTTPException(Exception):
    pass

class IncompleteRead(HTTPException):
    pass

class HTTPConnection():
    def __init__(self, *args, **kwargs):
        pass