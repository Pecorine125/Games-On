class Message():
    def __init__(*args, **kwargs):
        pass