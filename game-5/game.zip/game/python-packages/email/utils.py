def _has_surrogates():
    pass