from cookielib import (FileCookieJar)

class MozillaCookieJar(FileCookieJar):
    pass