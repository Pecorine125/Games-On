from requests import utils
from requests.exceptions import RequestException


def get(*args, **kwargs):
    raise RequestException()


def post(*args, **kwargs):
    raise RequestException()


class Headers:
    def __init__(self, *args, **kwargs):
        pass

    def update(self, *args, **kwargs):
        pass


class Session:
    def __init__(self, *args, **kwargs):
        self.headers = Headers()
