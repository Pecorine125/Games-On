class HTTPError(IOError):
    pass


class RequestException(IOError):
    pass


class ConnectionError(RequestException):
    pass
