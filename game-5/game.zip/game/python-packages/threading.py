class Thread():
    def __init__(self, *args, **kwargs):
        self.daemon = False

    def start(self):
        pass
