SIGINT = 0

def signal(*args, **kwargs):
    pass