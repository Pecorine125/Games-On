from cookielib import (FileCookieJar)

class LWPCookieJar(FileCookieJar):
    pass

def lwp_cookie_str(cookie):
    pass