_create_unverified_context = None
OPENSSL_VERSION = "0"


class SSLError(OSError):
    pass


class SSLWantReadError(SSLError):
    pass


class SSLSyscallError(SSLError):
    pass
